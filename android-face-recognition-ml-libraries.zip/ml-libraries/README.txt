Android Face Recognition — core ML libraries

Downloaded original versions:
- com.google.mlkit:face-detection:16.1.5
- org.tensorflow:tensorflow-lite:2.4.0

AAR binaries and POM dependency metadata are included.
Sources: https://dl.google.com/dl/android/maven2/ and https://repo.maven.apache.org/maven2/

Not included: tensorflow-lite-gpu:0.0.0-nightly and tensorflow-lite-support:0.0.0-nightly (HTTP 404 from Maven Central). The inspected MainActivity does not use their APIs.

This is NOT a complete offline Gradle build cache. Transitive dependencies, Android SDK, build tools, Gradle and other app dependencies are not included. Adding only these AARs via flatDir does not resolve their transitive dependencies. Use the POMs to inspect required dependencies, or resolve them with Gradle while online.

The MobileFaceNet model mobile_face_net.tflite is a separate project asset and is not included here.
